/* Copyright (C) Singapore University of Technology and Design - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Zeng Zimou <zimou_zeng@sutd.edu.sg>, August 2021
 */

#include <smorphi.h>

volatile char Smorphi :: targetSolenoid = 0;

volatile uint32_t Smorphi :: targetUltrasonic[4][5]= {0};

Smorphi* Smorphi::instance = nullptr;

Smorphi::Smorphi() 
  : shapeTimeout(shapeD, 1, 1),   // Initialize with appropriate arguments
    solenoidReset(solD, 1, 1)     // Initialize with appropriate arguments
{
  instance = this;
  shapeTimeout.setLoopCallback(&Smorphi :: staticKillSmorphi);
  solenoidReset.setLoopCallback(&Smorphi :: allSolenoidReset);
}

//Define the I2C address for each slave board
Adafruit_MotorShield AFMS1 (0x60);
Adafruit_MotorShield AFMS2 (0x61);
Adafruit_MotorShield AFMS3 (0x62);
Adafruit_MotorShield AFMS4 (0x63);

//Initialization for I/O expander on each slave board
Adafruit_MCP23X17 mcp1;
Adafruit_MCP23X17 mcp2;
Adafruit_MCP23X17 mcp3;
Adafruit_MCP23X17 mcp4;

//Adafruit calling (Swapped motor 3 & 4)
Adafruit_DCMotor *M11 = AFMS1.getMotor(1);
Adafruit_DCMotor *M12 = AFMS1.getMotor(2);
Adafruit_DCMotor *M13 = AFMS1.getMotor(4);
Adafruit_DCMotor *M14 = AFMS1.getMotor(3);

Adafruit_DCMotor *M21 = AFMS2.getMotor(1);
Adafruit_DCMotor *M22 = AFMS2.getMotor(2);
Adafruit_DCMotor *M23 = AFMS2.getMotor(4);
Adafruit_DCMotor *M24 = AFMS2.getMotor(3);

Adafruit_DCMotor *M31 = AFMS3.getMotor(1);
Adafruit_DCMotor *M32 = AFMS3.getMotor(2);
Adafruit_DCMotor *M33 = AFMS3.getMotor(4);
Adafruit_DCMotor *M34 = AFMS3.getMotor(3);

Adafruit_DCMotor *M41 = AFMS4.getMotor(1);
Adafruit_DCMotor *M42 = AFMS4.getMotor(2);
Adafruit_DCMotor *M43 = AFMS4.getMotor(4);
Adafruit_DCMotor *M44 = AFMS4.getMotor(3);

int Smorphi :: ultrasonicDistance(int mod, int sensor) {
  int trigPin; 
  if (sensor == 0) trigPin = 3;
  //else if (sensor == 1) trigPin = 13;
  //else if (sensor == 2) trigPin = 14;
  else if (sensor ==3) trigPin = 9;
  //else if (sensor == 4) trigPin = 14;
  else return -1;

  if (mod == 0) {
    mcp1.clearInterrupts();
    mcp1.digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    mcp1.digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    mcp1.digitalWrite(trigPin, LOW);
    targetUltrasonic [0][0] = millis();
  } 
  else if (mod == 1) {
    mcp2.digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    mcp2.digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    mcp2.digitalWrite(trigPin, LOW);

    
  } 
  else if (mod == 2) {
    mcp3.digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    mcp3.digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    mcp3.digitalWrite(trigPin, LOW);

  } 
  else if (mod == 3) {
    mcp4.digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    mcp4.digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    mcp4.digitalWrite(trigPin, LOW);
    
  } 
  else return -1;
  return 1;
}

void IRAM_ATTR Smorphi:: mod1Interrupted () {
  // int sensor = mcp1.getLastInterruptPin();
  // if (sensor == 2) sensor = 0;
  // else if (sensor == 12) sensor = 1;
  // else if (sensor == 13) sensor = 2;
  // else if (sensor == 8) sensor = 3;
  // else if (sensor == 14) sensor  = 4;

  // if (targetUltrasonic[0][sensor]<0) {
  //   targetUltrasonic[0][sensor] = (clockCyclesToMicroseconds(esp_cpu_get_cycle_count() + targetUltrasonic[0][sensor])*0.343)/2;
  // }

  // if (debug) Serial.print("Interrupted by mod 1 on pin ");
  // if (debug) Serial.println(instance -> mcp1.getLastInterruptPin());
  // if (targetSolenoid != 1|| targetSolenoid != 2) {
  //   //Reset Velocity
  //   staticKillSmorphi();
  // }
  // else if (!(instance -> sm_feedback(targetSolenoid))) {
    
  //   //Reset Velocity
  //   staticKillSmorphi();
  //   targetSolenoid = 0;
  // } else {
  //   if (debug) Serial.println(mcp1.digitalRead(INT_PIN_1));
  // }
  // mcp1.clearInterrupts();
  if (!targetSolenoid){
targetSolenoid = 1;
  targetUltrasonic[0][1] = esp_cpu_get_cycle_count();
  } else {
    targetSolenoid = 0;
      targetUltrasonic[0][2] = esp_cpu_get_cycle_count();
  }

  // mcp1.clearInterrupts();
}

void IRAM_ATTR Smorphi:: mod2Interrupted () {
  // int sensor = mcp2.getLastInterruptPin();
  // if (sensor == 2) sensor = 0;
  // else if (sensor == 12) sensor = 1;
  // else if (sensor == 13) sensor = 2;
  // else if (sensor == 8) sensor = 3;
  // else if (sensor == 14) sensor  = 4;
  // if (targetUltrasonic[1][sensor]<0) {
  //   targetUltrasonic[1][sensor] = (clockCyclesToMicroseconds(esp_cpu_get_cycle_count() + targetUltrasonic[1][sensor])*0.343)/2;
  // }
  // if (debug) Serial.print("Interrupted by mod 2 on pin ");
  // if (debug) Serial.println(instance -> mcp2.getLastInterruptPin());
  // if (targetSolenoid != 3) {
  //   //Reset Velocity
  //   staticKillSmorphi();;
  // }
  // else if (!(instance -> sm_feedback(targetSolenoid))) {
    
  //   //Reset Velocity
  //   staticKillSmorphi();
  //   targetSolenoid = 0;
  // } else {
  //   mcp2.getLastInterruptPin();
  // }
  targetSolenoid = 2;
  // mcp2.clearInterrupts();

}

void IRAM_ATTR Smorphi:: mod3Interrupted () {
  // int sensor = mcp3.getLastInterruptPin();
  // if (sensor == 2) sensor = 0;
  // else if (sensor == 12) sensor = 1;
  // else if (sensor == 13) sensor = 2;
  // else if (sensor == 8) sensor = 3;
  // else if (sensor == 14) sensor  = 4;
  // if (targetUltrasonic[2][sensor]<0) {
  //   targetUltrasonic[2][sensor] = (clockCyclesToMicroseconds(esp_cpu_get_cycle_count() + targetUltrasonic[2][sensor])*0.343)/2;
  // }
  // if (debug) Serial.print("Interrupted by mod 3 on pin ");
  // if (debug) Serial.println(instance -> mcp3.getLastInterruptPin());
  // if (targetSolenoid != 4 || targetSolenoid != 5) {
  //   //Reset Velocity
  //   staticKillSmorphi();
  // }
  // else if (!(instance -> sm_feedback(targetSolenoid))) {
    
  //   //Reset Velocity
  //   staticKillSmorphi();
  //   targetSolenoid = 0;
  // } else {
  //   mcp3.getLastInterruptPin();
  // }
    targetSolenoid = 3;

//mcp3.clearInterrupts();
}

void IRAM_ATTR Smorphi:: mod4Interrupted () {
  // int sensor = mcp4.getLastInterruptPin();
  // if (sensor == 2) sensor = 0;
  // else if (sensor == 12) sensor = 1;
  // else if (sensor == 13) sensor = 2;
  // else if (sensor == 8) sensor = 3;
  // else if (sensor == 14) sensor  = 4;
  // if (targetUltrasonic[3][sensor]<0) {
  //   targetUltrasonic[3][sensor] = (clockCyclesToMicroseconds(esp_cpu_get_cycle_count() + targetUltrasonic[3][sensor])*0.343)/2;
  // }
  // if (debug) Serial.print("Interrupted by mod 4 on pin ");
  // if (debug) Serial.println(instance -> mcp4.getLastInterruptPin());
  // if (targetSolenoid != 6) {
  //   //Reset Velocity
  //   staticKillSmorphi();
  // }
  // else if (!(instance -> sm_feedback(targetSolenoid))) {
    
  //   //Reset Velocity
  //   staticKillSmorphi();
  //   targetSolenoid = 0;
  // } else {
  //   mcp4.getLastInterruptPin();
  // }
    targetSolenoid = 4;
// mcp4.clearInterrupts();
}

bool Smorphi::interruptTriggered() {
    if (targetSolenoid) {
        return true;
    }
    return false;
}
void Smorphi::resetInter(){
  mcp1.clearInterrupts();
}

void Smorphi::BeginSmorphi()
{
  //begin the pwm driver
  AFMS1.begin();
  AFMS2.begin();
  AFMS3.begin();
  AFMS4.begin();

  //begin the I/O expander
  mcp1.begin_I2C(0x20); //LSM bit swapped for GPIO expander and PWM driver
  mcp2.begin_I2C(0x21);
  mcp3.begin_I2C(0x22);
  mcp4.begin_I2C(0x23);

  // setup for I/O expander pins - alternate between INPUT_PULLUP and OUTPUT
  // pin 7 and 15 might have problems in input mode

  for (int i = 0; i < 16; i++) {
    if (!(i % 2) || i == 13 || i == 15) {
      mcp1.pinMode(i, INPUT_PULLUP);
      mcp2.pinMode(i, INPUT_PULLUP);
      mcp3.pinMode(i, INPUT_PULLUP);
      mcp4.pinMode(i, INPUT_PULLUP);
      mcp1.setupInterruptPin(i, CHANGE);
      mcp2.setupInterruptPin(i, CHANGE);
      mcp3.setupInterruptPin(i, CHANGE);
      mcp4.setupInterruptPin(i, CHANGE);
    } else {
      mcp1.pinMode(i, OUTPUT);
      mcp2.pinMode(i, OUTPUT);
      mcp3.pinMode(i, OUTPUT);
      mcp4.pinMode(i, OUTPUT);
    }

  }
  set_interrupt_pin();

  //setup for interrupts for all pins - Mirror interrupts, active-low, trigger on LOW
  mcp1.setupInterrupts(true, LOW, LOW); // overridden
  mcp2.setupInterrupts(true, LOW, LOW);
  mcp3.setupInterrupts(true, LOW, LOW);
  mcp4.setupInterrupts(true, LOW, LOW);

  mcp1.readGPIOAB();
  mcp2.readGPIOAB();
  mcp3.readGPIOAB();
  mcp4.readGPIOAB();

    //4 interrupt pins on master board
  pinMode(INT_PIN_1, INPUT); //for module 1
  pinMode(INT_PIN_2, INPUT); //for module 2
  pinMode(INT_PIN_3, INPUT); //for module 3
  pinMode(INT_PIN_4, INPUT); //for module 4

  // ::attachInterrupt(INT_PIN_1, mod1Interrupted, FALLING);
  // ::attachInterrupt(INT_PIN_2, mod2Interrupted, CHANGE);
  // ::attachInterrupt(INT_PIN_3, mod3Interrupted, CHANGE);
  // ::attachInterrupt(INT_PIN_4, mod4Interrupted, CHANGE);
}

// EVerything here is wrong - second argument should be RISING (3), FALLING(1) or CHANGE(2)
// HIGH is 1 and LOW is 0
void Smorphi::set_interrupt_pin(){

  //Initialize solenoid status pins according to shapes - overwrites setupInterrupts func
  if (sm_getShape() == 'o'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, RISING);
    mcp2.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(15, RISING);
    mcp4.setupInterruptPin(14, FALLING);
  }

  if (sm_getShape() == 'i'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, RISING);
    mcp2.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(15, RISING);
    mcp4.setupInterruptPin(14, FALLING);
  }

  if (sm_getShape() == 'l'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, RISING);
    mcp2.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(15, FALLING);
    mcp4.setupInterruptPin(14, RISING);
  }

  if (sm_getShape() == 'z'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, FALLING);
    mcp2.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(15, FALLING);
    mcp4.setupInterruptPin(14, RISING);
  }

  if (sm_getShape() == 't'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, FALLING);
    mcp2.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(15, RISING);
    mcp4.setupInterruptPin(14, RISING);
  }

  if (sm_getShape() == 's'){
    mcp1.setupInterruptPin(14, RISING);
    mcp1.setupInterruptPin(15, FALLING);
    mcp2.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(15, RISING);
    mcp4.setupInterruptPin(14, FALLING);
  }

  if (sm_getShape() == 'j'){
    mcp1.setupInterruptPin(14, FALLING);
    mcp1.setupInterruptPin(15, RISING);
    mcp2.setupInterruptPin(14, RISING);
    mcp3.setupInterruptPin(14, FALLING);
    mcp3.setupInterruptPin(15, FALLING);
    mcp4.setupInterruptPin(14, RISING);
  }
  
}

// setup for sensor status check for module1

int Smorphi::module1_sensor_status(int pin_no){
  return mcp1.digitalRead(pin_no);
}

// setup for sensor status check for module2
int Smorphi::module2_sensor_status(int pin_no){
  return mcp2.digitalRead(pin_no);
}

// setup for sensor status check for module3
int Smorphi::module3_sensor_status(int pin_no){
  return mcp3.digitalRead(pin_no);
}

// setup for sensor status check for module4
int Smorphi::module4_sensor_status(int pin_no){
  return mcp4.digitalRead(pin_no);
}

// write digital value to specified pin
void Smorphi::module1_sensor_write(int pin_no, int state){
  mcp1.digitalWrite(pin_no, state);
  return;
}

void Smorphi::module2_sensor_write(int pin_no, int state){
  mcp2.digitalWrite(pin_no,state);
  return;
}

void Smorphi::module3_sensor_write(int pin_no, int state){
  mcp3.digitalWrite(pin_no,state);
  return;
}

void Smorphi::module4_sensor_write(int pin_no, int state){
  mcp4.digitalWrite(pin_no, state);
  return;
}

// mapping fomula: (x-in_min) * (out_max-out_min) / (in_max-in_min) + out_min
double Smorphi::mapPosRanges(int ipSpeed) //map user's input linear velocity to robot's actual positive linear velocity
{
  double mappedSpeed = ipSpeed * (sm_max_linear_speed) / 100;
  return mappedSpeed;
}

double Smorphi::mapNegRanges(int ipSpeed) //map user's input linear velocity to robot's actual negative linear velocity
{
  double mappedSpeed = ipSpeed * (-sm_max_linear_speed) / 100;
  return mappedSpeed;
}

double Smorphi::mapPosAng(int ipSpeed) //map user's input angular velocity to robot's actual positive angular velocity
{
  double mappedSpeed = ipSpeed * (sm_max_angular_speed) / 100;
  return mappedSpeed;
}

double Smorphi::mapNegAng(int ipSpeed) //map user's input angular velocity to robot's actual negative angular velocity
{
  double mappedSpeed = ipSpeed * (-sm_max_angular_speed) / 100;
  return mappedSpeed;
}

int Smorphi::map_lv_PWM(double ipSpeed) //map robot's linear velocity to PWM
{
  if (ipSpeed == 0)
  {
    if (debug) Serial.println("WHAT THE HELL");
    int mappedPWM = 0;
    return mappedPWM;
  }
  else
  {
    int mappedPWM = ipSpeed * (sm_pwm_upper_limit - sm_pwm_lower_limit) / sm_max_linear_speed + sm_pwm_lower_limit;
    return mappedPWM;
  }
  
}

int Smorphi::map_ang_PWM(double ipSpeed) //map robot's angular velocity to PWM
{
  if (ipSpeed == 0)
  {
    int mappedPWM = 0;
    return mappedPWM;
  }
  else
  {
    int mappedPWM = ipSpeed * (sm_pwm_upper_limit - sm_pwm_lower_limit) / sm_max_angular_speed + sm_pwm_lower_limit;
    return mappedPWM;
  }
  
}

int Smorphi::map_turn_PWM(double ipSpeed) //map robot's curve velocity to PWM
{
  if (ipSpeed == 0)
  {
    int mappedPWM = 0;
    return mappedPWM;
  }
  else
  {
    int mappedPWM = ipSpeed * (sm_pwm_upper_limit - sm_pwm_lower_limit) / sm_max_curve_speed + sm_pwm_lower_limit; 
    return mappedPWM;
  }
  
}

//get solenoid feedback
int Smorphi::sm_feedback(int solenoid_feedback){ 
  if (solenoid_feedback == 1){
    feedback_val = mcp1.digitalRead(14);
  }
  else if (solenoid_feedback == 2) {
    feedback_val = mcp1.digitalRead(15);
  }
  else if (solenoid_feedback == 3) {
    feedback_val = mcp2.digitalRead(14);
  }
  else if (solenoid_feedback == 4) {
    feedback_val = mcp3.digitalRead(14);
  }
  else if (solenoid_feedback == 5) {
    feedback_val = mcp3.digitalRead(15);
  }
  else if (solenoid_feedback == 6) {
    feedback_val = mcp4.digitalRead(14);
  }
  
  return feedback_val;
}

//set HIGH or LOW to the solenoid
void Smorphi::sm_solenoid_set(int solenoid_unlock, bool status){ 
  if (solenoid_unlock == 1){
    AFMS1.setPin(0, status);
  }
  else if (solenoid_unlock == 2){
    AFMS1.setPin(1, status);
  }
  else if (solenoid_unlock == 3){
    AFMS2.setPin(0, status);
  }
  else if (solenoid_unlock == 4){
    AFMS3.setPin(0, status);
  }
  else if (solenoid_unlock == 5){
    AFMS3.setPin(1, status);
  }
  else if (solenoid_unlock == 6){
    AFMS4.setPin(0, status);
  }
  
}

void Smorphi::allSolenoidReset() {
  if (debug) Serial.println("Resetting all solenoids");
  AFMS1.setPin(0, LOW);
  AFMS1.setPin(1, LOW);
  AFMS2.setPin(0, LOW);
  AFMS3.setPin(0, LOW);
  AFMS3.setPin(1, LOW);
  AFMS4.setPin(0, LOW);
  targetSolenoid = 0;
}

//get the current shape 
char Smorphi::sm_getShape(){ 
  //   if (sm_feedback(1)==1 && sm_feedback(2)==1 && sm_feedback(3)==1 && sm_feedback(4)==1 && sm_feedback(5)==1 && sm_feedback(6)==1){
  //   robot_shape = 'i';
  // }
  if (sm_feedback(1)==0 && sm_feedback(2)==1 && sm_feedback(3)==0 && sm_feedback(4)==1 && sm_feedback(5)==1 && sm_feedback(6)==0){
    robot_shape = 'i';
  }

  else if ((sm_feedback(1)==0 && sm_feedback(2)==1 && sm_feedback(3)==0 && sm_feedback(4)==1 && sm_feedback(5)==0 && sm_feedback(6)==1)){
    robot_shape = 'l';
  }

  else if (sm_feedback(1)==0 && sm_feedback(2)==0 && sm_feedback(3)==1 && sm_feedback(4)==1 && sm_feedback(5)==0 && sm_feedback(6)==1){
    robot_shape = 'z';
  }

  else if (sm_feedback(1)==0 && sm_feedback(2)==1 && sm_feedback(3)==1 && sm_feedback(4)==0 && sm_feedback(5)==1 && sm_feedback(6)==0){
    robot_shape = 'o';
  }

  else if (sm_feedback(1)==0 && sm_feedback(2)==0 && sm_feedback(3)==1 && sm_feedback(4)==0 && sm_feedback(5)==1 && sm_feedback(6)==1){
    robot_shape = 't';
  }

  else if (sm_feedback(1)==1 && sm_feedback(2)==0 && sm_feedback(3)==1 && sm_feedback(4)==0 && sm_feedback(5)==1 && sm_feedback(6)==0){
    robot_shape = 's';
  }

  else if (sm_feedback(1)==0 && sm_feedback(2)==1 && sm_feedback(3)==1 && sm_feedback(4)==0 && sm_feedback(5)==0 && sm_feedback(6)==1){
    robot_shape = 'j';
  }
  else
  {
    robot_shape = 'i';
  }
  if (debug) Serial.print("Shape detected is ");
  if (debug) Serial.println(robot_shape);
  return robot_shape;
}

//Kinematic equations for all shapes
void Smorphi::sm_velocity_handler(float sm_req_linear_speed_x, float sm_req_linear_speed_y, float sm_req_angular_speed)
{
  float v_x = sm_req_linear_speed_x;
  float v_y = sm_req_linear_speed_y;
  float w   = sm_req_angular_speed;

  char shape = sm_getShape();

  //   // Module 1
  // sm_lv_M1FL  =  ( v_x - v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M1FR  =  ( v_x + v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M1RL  =  ( v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M1RR  =  ( v_x - v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  // // Module 2
  // sm_lv_M2FL  =  ( v_x - v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M2FR  =  ( v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M2RL  =  ( v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M2RR  =  ( v_x - v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

  // // Module 3
  // sm_lv_M3FL  =  ( -v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M3FR  =  ( -v_x - v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M3RL  =  ( -v_x - v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M3RR  =  ( -v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

  // // Module 4
  // sm_lv_M4FL  =  ( -v_x + v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M4FR  =  ( -v_x - v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M4RL  =  ( -v_x - v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
  // sm_lv_M4RR  =  ( -v_x + v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  if (shape == 'o')
  {
    //Module 1 
    sm_lv_M1FL  =  ( v_x - v_y - ( sm_wheel_x + sm_wheel_y) * w ); 
    sm_lv_M1FR  =  ( v_x + v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w ); 
    sm_lv_M1RL  =  ( v_x + v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w ); 
    sm_lv_M1RR  =  ( v_x - v_y + ( sm_wheel_x + sm_wheel_y) * w ); 

    // Module 2
    sm_lv_M2FL  =  ( v_x - v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  ( v_x + v_y + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  ( v_x + v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  ( v_x - v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 3
    sm_lv_M3FL  =  ( v_x - v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  ( v_x + v_y - 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  ( v_x + v_y - 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  ( v_x - v_y + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 4
    sm_lv_M4FL  =  ( v_x - v_y - 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  ( v_x + v_y + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  ( v_x + v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  ( v_x - v_y - 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );

  }

  else if (shape == 's')
  {
    // Module 1
    sm_lv_M1FL  =  (-v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  (-v_x - v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  (-v_x - v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  (-v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 2
    sm_lv_M2FL  =  (v_x - v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  (v_x + v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  (v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  (v_x - v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 3
    sm_lv_M3FL  =  ( v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  (-v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  (-v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  ( v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 4
    sm_lv_M4FL  =  ( v_x + v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  (-v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  (-v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  ( v_x + v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  }

  else if (shape == 'z')
  {
    // Module 1
    sm_lv_M1FL  =  (-v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  (-v_x - v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  (-v_x - v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  (-v_x + v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 2
    sm_lv_M2FL  =  (v_x - v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  (v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  (v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  (v_x - v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 3
    sm_lv_M3FL  =  (-v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  (-v_x - v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  (-v_x - v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  (-v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );


    // Module 4
    sm_lv_M4FL  =  (v_x - v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  (v_x + v_y + 0.085  * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  (v_x + v_y + 0.085  * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  (v_x - v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  }

  else if (shape == 'i')
  {
    // Module 1
    sm_lv_M1FL  =  ( v_x - v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  ( v_x + v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  ( v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  ( v_x - v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 2
    sm_lv_M2FL  =  ( v_x - v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  ( v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  ( v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  ( v_x - v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 3
    sm_lv_M3FL  =  ( -v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  ( -v_x - v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  ( -v_x - v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  ( -v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 4
    sm_lv_M4FL  =  ( -v_x + v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  ( -v_x - v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  ( -v_x - v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  ( -v_x + v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  }



  else if (shape == 'l')
  {
    // Module 1
    sm_lv_M1FL  =  ( v_x - v_y - 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  ( v_x + v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  ( v_x + v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  ( v_x - v_y - 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 2
    sm_lv_M2FL  =  ( v_x - v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  ( v_x + v_y + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  ( v_x + v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  ( v_x - v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 3
    sm_lv_M3FL  =  ( -v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  ( -v_x - v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  ( -v_x - v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  ( -v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 4
    sm_lv_M4FL  =  ( v_x - v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  ( v_x + v_y + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  ( v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  ( v_x - v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );

  }

  else if (shape == 'j')
  {
    // Module 1
    sm_lv_M1FL  =  ( v_x - v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  ( v_x + v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  ( v_x + v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  ( v_x - v_y + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 2
    sm_lv_M2FL  =  ( v_x - v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  ( v_x + v_y + 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  ( v_x + v_y + 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  ( v_x - v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 3
    sm_lv_M3FL  =  ( v_x - v_y - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  ( v_x + v_y - 0.085 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  ( v_x + v_y - 0.085 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  ( v_x - v_y + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 4
    sm_lv_M4FL  =  (-v_x + v_y + 0.17 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  (-v_x - v_y + 0.255 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  (-v_x - v_y + 0.255 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  (-v_x + v_y + 0.17 * w + ( sm_wheel_x + sm_wheel_y) * w );


  }

  else if (shape == 't')
  {
    // Module 1
    // sm_lv_M1FL  =  -(-v_x - v_y - 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    // sm_lv_M1FR  =  -( v_x - v_y - 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );
    // sm_lv_M1RL  =  -( v_x - v_y - 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    // sm_lv_M1RR  =  -(-v_x - v_y - 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FL  =  ( v_x + v_y + 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1FR  =  (-v_x + v_y + 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RL  =  (-v_x + v_y + 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M1RR  =  ( v_x + v_y + 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 2
    sm_lv_M2FL  =  (v_x - v_y + 0.2125 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2FR  =  (v_x + v_y + 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RL  =  (v_x + v_y + 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M2RR  =  (v_x - v_y + 0.2125 * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 3
    sm_lv_M3FL  =  (v_x - v_y + 0.0425  * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3FR  =  (v_x + v_y - 0.0425  * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RL  =  (v_x + v_y - 0.0425  * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M3RR  =  (v_x - v_y + 0.0425  * w + ( sm_wheel_x + sm_wheel_y) * w );

    // Module 4
    sm_lv_M4FL  =  (-v_x + v_y + 0.1275 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4FR  =  (-v_x - v_y + 0.2125 * w + ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RL  =  (-v_x - v_y + 0.2125 * w - ( sm_wheel_x + sm_wheel_y) * w );
    sm_lv_M4RR  =  (-v_x + v_y + 0.1275 * w + ( sm_wheel_x + sm_wheel_y) * w );
  
  }

  // Serial.println("=========Linear_Velocity==========");
  // Serial.println(sm_lv_M1FL,3);
  // Serial.println(sm_lv_M1FR,3);
  // Serial.println(sm_lv_M1RL,3);
  // Serial.println(sm_lv_M1RR,3);
  // Serial.println("------------------");
  // Serial.println(sm_lv_M2FL,3);
  // Serial.println(sm_lv_M2FR,3);
  // Serial.println(sm_lv_M2RL,3);
  // Serial.println(sm_lv_M2RR,3);
  // Serial.println("------------------");
  // Serial.println(sm_lv_M3FL,3);
  // Serial.println(sm_lv_M3FR,3);
  // Serial.println(sm_lv_M3RL,3);
  // Serial.println(sm_lv_M3RR,3);
  // Serial.println("------------------");
  // Serial.println(sm_lv_M4FL,3);
  // Serial.println(sm_lv_M4FR,3);
  // Serial.println(sm_lv_M4RL,3);
  // Serial.println(sm_lv_M4RR,3); 
  // Serial.println("=========Linear_Velocity==========");
}

//map velocity after kinematics to pwm
void Smorphi::sm_pwm_handler(int flag)
{
    if (debug) Serial.println("Entered PWM Handler");

    if(flag==0){
      //Module 1
      sm_PWM_M1FL = map_lv_PWM(abs(sm_lv_M1FL));
      sm_PWM_M1FR = map_lv_PWM(abs(sm_lv_M1FR));
      sm_PWM_M1RR = map_lv_PWM(abs(sm_lv_M1RR));
      sm_PWM_M1RL = map_lv_PWM(abs(sm_lv_M1RL));

      //Module 2
      sm_PWM_M2FL = map_lv_PWM(abs(sm_lv_M2FL));
      sm_PWM_M2FR = map_lv_PWM(abs(sm_lv_M2FR));
      sm_PWM_M2RR = map_lv_PWM(abs(sm_lv_M2RR));
      sm_PWM_M2RL = map_lv_PWM(abs(sm_lv_M2RL));

      //Module 3
      sm_PWM_M3FL = map_lv_PWM(abs(sm_lv_M3FL));
      sm_PWM_M3FR = map_lv_PWM(abs(sm_lv_M3FR));
      sm_PWM_M3RR = map_lv_PWM(abs(sm_lv_M3RR));
      sm_PWM_M3RL = map_lv_PWM(abs(sm_lv_M3RL));


      //Module 4
      sm_PWM_M4FL = map_lv_PWM(abs(sm_lv_M4FL));
      sm_PWM_M4FR = map_lv_PWM(abs(sm_lv_M4FR));
      sm_PWM_M4RR = map_lv_PWM(abs(sm_lv_M4RR));
      sm_PWM_M4RL = map_lv_PWM(abs(sm_lv_M4RL));
    }

    else if(flag==1){
      //Module 1
      sm_PWM_M1FL = map_turn_PWM(abs(sm_lv_M1FL));
      sm_PWM_M1FR = map_turn_PWM(abs(sm_lv_M1FR));
      sm_PWM_M1RR = map_turn_PWM(abs(sm_lv_M1RR));
      sm_PWM_M1RL = map_turn_PWM(abs(sm_lv_M1RL));

      //Module 2
      sm_PWM_M2FL = map_turn_PWM(abs(sm_lv_M2FL));
      sm_PWM_M2FR = map_turn_PWM(abs(sm_lv_M2FR));
      sm_PWM_M2RR = map_turn_PWM(abs(sm_lv_M2RR));
      sm_PWM_M2RL = map_turn_PWM(abs(sm_lv_M2RL));

      //Module 3
      sm_PWM_M3FL = map_turn_PWM(abs(sm_lv_M3FL));
      sm_PWM_M3FR = map_turn_PWM(abs(sm_lv_M3FR));
      sm_PWM_M3RR = map_turn_PWM(abs(sm_lv_M3RR));
      sm_PWM_M3RL = map_turn_PWM(abs(sm_lv_M3RL));


      //Module 4
      sm_PWM_M4FL = map_turn_PWM(abs(sm_lv_M4FL));
      sm_PWM_M4FR = map_turn_PWM(abs(sm_lv_M4FR));
      sm_PWM_M4RR = map_turn_PWM(abs(sm_lv_M4RR));
      sm_PWM_M4RL = map_turn_PWM(abs(sm_lv_M4RL));
    }

    else if(flag==2){
      //Module 1
      sm_PWM_M1FL = map_ang_PWM(abs(sm_lv_M1FL));
      sm_PWM_M1FR = map_ang_PWM(abs(sm_lv_M1FR));
      sm_PWM_M1RR = map_ang_PWM(abs(sm_lv_M1RR));
      sm_PWM_M1RL = map_ang_PWM(abs(sm_lv_M1RL));

      //Module 2
      sm_PWM_M2FL = map_ang_PWM(abs(sm_lv_M2FL));
      sm_PWM_M2FR = map_ang_PWM(abs(sm_lv_M2FR));
      sm_PWM_M2RR = map_ang_PWM(abs(sm_lv_M2RR));
      sm_PWM_M2RL = map_ang_PWM(abs(sm_lv_M2RL));

      //Module 3
      sm_PWM_M3FL = map_ang_PWM(abs(sm_lv_M3FL));
      sm_PWM_M3FR = map_ang_PWM(abs(sm_lv_M3FR));
      sm_PWM_M3RR = map_ang_PWM(abs(sm_lv_M3RR));
      sm_PWM_M3RL = map_ang_PWM(abs(sm_lv_M3RL));


      //Module 4
      sm_PWM_M4FL = map_ang_PWM(abs(sm_lv_M4FL));
      sm_PWM_M4FR = map_ang_PWM(abs(sm_lv_M4FR));
      sm_PWM_M4RR = map_ang_PWM(abs(sm_lv_M4RR));
      sm_PWM_M4RL = map_ang_PWM(abs(sm_lv_M4RL));
    }

    else if(flag==3){
      //Module 1
      sm_PWM_M1FL = map_lv_PWM(abs(sm_lv_M1FL)) - sm_pwm_lower_limit;
      sm_PWM_M1FR = map_lv_PWM(abs(sm_lv_M1FR)) - sm_pwm_lower_limit;
      sm_PWM_M1RR = map_lv_PWM(abs(sm_lv_M1RR)) - sm_pwm_lower_limit;
      sm_PWM_M1RL = map_lv_PWM(abs(sm_lv_M1RL)) - sm_pwm_lower_limit;

      //Module 2
      sm_PWM_M2FL = map_lv_PWM(abs(sm_lv_M2FL)) - sm_pwm_lower_limit;
      sm_PWM_M2FR = map_lv_PWM(abs(sm_lv_M2FR)) - sm_pwm_lower_limit;
      sm_PWM_M2RR = map_lv_PWM(abs(sm_lv_M2RR)) - sm_pwm_lower_limit;
      sm_PWM_M2RL = map_lv_PWM(abs(sm_lv_M2RL)) - sm_pwm_lower_limit;

      //Module 3
      sm_PWM_M3FL = map_lv_PWM(abs(sm_lv_M3FL)) - sm_pwm_lower_limit;
      sm_PWM_M3FR = map_lv_PWM(abs(sm_lv_M3FR)) - sm_pwm_lower_limit;
      sm_PWM_M3RR = map_lv_PWM(abs(sm_lv_M3RR)) - sm_pwm_lower_limit;
      sm_PWM_M3RL = map_lv_PWM(abs(sm_lv_M3RL)) - sm_pwm_lower_limit;


      //Module 4
      sm_PWM_M4FL = map_lv_PWM(abs(sm_lv_M4FL)) - sm_pwm_lower_limit;
      sm_PWM_M4FR = map_lv_PWM(abs(sm_lv_M4FR)) - sm_pwm_lower_limit;
      sm_PWM_M4RR = map_lv_PWM(abs(sm_lv_M4RR)) - sm_pwm_lower_limit;
      sm_PWM_M4RL = map_lv_PWM(abs(sm_lv_M4RL)) - sm_pwm_lower_limit;
    }
    
    // Serial.println("================PWM================");
    // Serial.println(sm_PWM_M1FL);
    // Serial.println(sm_PWM_M1FR);
    // Serial.println(sm_PWM_M1RL);
    // Serial.println(sm_PWM_M1RR);
    // Serial.println("------------------");
    // Serial.println(sm_PWM_M2FL);
    // Serial.println(sm_PWM_M2FR);
    // Serial.println(sm_PWM_M2RL);
    // Serial.println(sm_PWM_M2RR);
    // Serial.println("------------------");
    // Serial.println(sm_PWM_M3FL);
    // Serial.println(sm_PWM_M3FR);
    // Serial.println(sm_PWM_M3RL);
    // Serial.println(sm_PWM_M3RR);
    // Serial.println("------------------");
    // Serial.println(sm_PWM_M4FL);
    // Serial.println(sm_PWM_M4FR);
    // Serial.println(sm_PWM_M4RL);
    // Serial.println(sm_PWM_M4RR);
    // Serial.println("================PWM================");

    //store all the pwm values inside an array
    double sm_PWMs[4][4] = {{sm_PWM_M1FL, sm_PWM_M1FR, sm_PWM_M1RL, sm_PWM_M1RR},
              {sm_PWM_M2FL, sm_PWM_M2FR, sm_PWM_M2RL, sm_PWM_M2RR},
              {sm_PWM_M3FL, sm_PWM_M3FR, sm_PWM_M3RL, sm_PWM_M3RR},
              {sm_PWM_M4FL, sm_PWM_M4FR, sm_PWM_M4RL, sm_PWM_M4RR}
            };
    //set speed to each motor
    SetSmorphiSpeed(sm_PWMs);
}

void Smorphi::SetSmorphiSpeed(double pwm[4][4])
{
  if (debug) Serial.println("Setting speed");
  M11->setSpeed(pwm[0][0]);
  M12->setSpeed(pwm[0][1]);
  M13->setSpeed(pwm[0][2]);
  M14->setSpeed(pwm[0][3]);

  M21->setSpeed(pwm[1][0]);
  M22->setSpeed(pwm[1][1]);
  M23->setSpeed(pwm[1][2]);
  M24->setSpeed(pwm[1][3]);

  M31->setSpeed(pwm[2][0]);
  M32->setSpeed(pwm[2][1]);
  M33->setSpeed(pwm[2][2]);
  M34->setSpeed(pwm[2][3]);

  M41->setSpeed(pwm[3][0]);
  M42->setSpeed(pwm[3][1]);
  M43->setSpeed(pwm[3][2]);
  M44->setSpeed(pwm[3][3]);

}

//handle the motor driving direction
void Smorphi::MotorDirection(){

  double sm_lvs[4][4] = {{sm_lv_M1FL,sm_lv_M1FR,sm_lv_M1RL,sm_lv_M1RR},
                    {sm_lv_M2FL,sm_lv_M2FR,sm_lv_M2RL,sm_lv_M2RR},
                    {sm_lv_M3FL,sm_lv_M3FR,sm_lv_M3RL,sm_lv_M3RR},
                    {sm_lv_M4FL,sm_lv_M4FR,sm_lv_M4RL,sm_lv_M4RR}};

  Adafruit_DCMotor *sm_motors[4][4] = {{M11,M12,M13,M14},
                      {M21,M22,M23,M24},
                      {M31,M32,M33,M34},
                      {M41,M42,M43,M44}};

  for (int i=0; i<4; i++){
    for (int j=0; j<4; j++){
      if (sm_lvs[i][j] > 0.001) {
        sm_motors[i][j]->run(FORWARD);
      }
      if (sm_lvs[i][j] == 0) {
        sm_motors[i][j]->run(RELEASE);
      }
      if (sm_lvs[i][j] < -0.001) {
        sm_motors[i][j]->run(BACKWARD);
      }
    }
  }
}

//Locomotion functions
void Smorphi::MoveForward(const int Speed)
{
  double vel_speed = mapPosRanges(Speed);
  // if (debug) Serial.println(vel_speed);
  sm_velocity_handler(vel_speed, 0, 0);
  int flag = 0;
  sm_pwm_handler(flag);
  MotorDirection(); 
}

void Smorphi::MoveBackward(const int Speed)
{
  double vel_speed = mapNegRanges(Speed);
  sm_velocity_handler(vel_speed, 0, 0);
  int flag = 0;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::MoveRight(const int Speed)
{
  double vel_speed = mapNegRanges(Speed);
  sm_velocity_handler(0, vel_speed, 0);
  int flag = 0;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::MoveLeft(const int Speed)
{
  double vel_speed = mapPosRanges(Speed);
  sm_velocity_handler(0, vel_speed, 0);
  int flag = 0;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::MoveDiagUpRight(const int Speed)
{
  double vel_speed_x = mapPosRanges(Speed)/2;
  double vel_speed_y = mapNegRanges(Speed)/2;
  sm_velocity_handler(vel_speed_x+0.001, vel_speed_y, 0);
  int flag = 3;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::MoveDiagUpLeft(const int Speed)
{
  double vel_speed = mapPosRanges(Speed)/2;
  sm_velocity_handler(vel_speed+0.001, vel_speed, 0);
  int flag = 3;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveDiagDownRight(const int Speed)
{

  double vel_speed = mapNegRanges(Speed)/2;
  sm_velocity_handler(vel_speed-0.001, vel_speed, 0);
  int flag = 3;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveDiagDownLeft(const int Speed)
{
  
  double vel_speed_x = mapNegRanges(Speed)/2;
  double vel_speed_y = mapPosRanges(Speed)/2;
  sm_velocity_handler(vel_speed_x-0.001, vel_speed_y, 0);
  int flag = 3;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveTurnUpRight(const int Speed, const int angular_velocity)
{
  
  double vel_speed = mapPosRanges(Speed);
  double ang_speed = mapNegAng(angular_velocity);
  sm_velocity_handler(vel_speed, 0, ang_speed);
  int flag = 1;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveTurnUpLeft(const int Speed, const int angular_velocity)
{
  
  double vel_speed = mapPosRanges(Speed);
  double ang_speed = mapPosAng(angular_velocity);
  sm_velocity_handler(vel_speed, 0, ang_speed);
  int flag = 1;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveTurnDownRight(const int Speed, const int angular_velocity)
{
  
  double vel_speed = mapNegRanges(Speed);
  double ang_speed = mapNegAng(angular_velocity);
  sm_velocity_handler(vel_speed, 0, ang_speed);
  int flag = 1;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::MoveTurnDownLeft(const int Speed, const int angular_velocity)
{
  double vel_speed = mapNegRanges(Speed);
  double ang_speed = mapPosAng(angular_velocity);
  sm_velocity_handler(vel_speed, 0, ang_speed);
  int flag = 1;
  sm_pwm_handler(flag);
  MotorDirection();

}

void Smorphi::HingePivotLeft(int Speed, int mod)
{
    mod ++;

  double w = mapPosAng(350);
  sm_reset_M1();
    sm_reset_M2();
    sm_reset_M3();
    sm_reset_M4();
  switch (mod)
  {
  case 1:
    // Module 1
    // Module 1
      sm_lv_M1FL  =  ( - ( sm_wheel_x + sm_wheel_y) * (-w) ) * 2;
      sm_lv_M1FR  =  ( 0.17 * (-w) + ( sm_wheel_x + sm_wheel_y) * (-w) ) * 2;
      sm_lv_M1RL  =  ( 0.17 * (-w) - ( sm_wheel_x + sm_wheel_y) * (-w) ) * 2;
      sm_lv_M1RR  =  ( ( sm_wheel_x + sm_wheel_y) * (-w) ) * 2;

    sm_pwm_handler(2);
    MotorDirection();
    break;
    

  case 2:
    // Module 1
    sm_lv_M1FL = (-0.17 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M1FR = ((sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M1RL = (-(sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M1RR = (-0.17 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;

    // Module 2
    sm_lv_M2FL = (-0.34 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M2FR = (0.17 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M2RL = (0.17 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M2RR = (-0.34 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;

    sm_pwm_handler(2);
    MotorDirection();
    break;

  case 3:
    // Module 3
    sm_lv_M3FL = (-0.17 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M3FR = ((sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M3RL = (-(sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M3RR = (-0.17 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;

    // Module 4
    sm_lv_M4FL = (-0.34 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4FR = (0.17 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4RL = (0.17 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4RR = (-0.34 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;

    sm_pwm_handler(2);
    MotorDirection();
    break;

  case 4:

    // Module 4
    sm_lv_M4FL = (-(sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4FR = (0.17 * w + (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4RL = (0.17 * w - (sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_lv_M4RR = ((sm_wheel_x + sm_wheel_y) * w) * 2;
    sm_pwm_handler(2);
    MotorDirection();
    break;
  }
}

void Smorphi::HingePivotRight(int Speed, int mod)
{
  mod ++;
  sm_reset_M1();
    sm_reset_M2();
    sm_reset_M3();
    sm_reset_M4();
  double w = mapPosAng(350);
  switch (mod)
  {
  case 1:
  
    // Module 1
    sm_lv_M1FL  =  ( - ( sm_wheel_x + sm_wheel_y) * (w) ) * 2;
      sm_lv_M1FR  =  ( 0.17 * (w) + ( sm_wheel_x + sm_wheel_y) * (w) ) * 2;
      sm_lv_M1RL  =  ( 0.17 * (w) - ( sm_wheel_x + sm_wheel_y) * (w) ) * 2;
      sm_lv_M1RR  =  ( ( sm_wheel_x + sm_wheel_y) * (w) ) * 2;

    sm_pwm_handler(2);
    MotorDirection();
    break;

      
  case 2:
    // Module 1
    sm_lv_M1FL = (-0.17 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M1FR = ((sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M1RL = (-(sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M1RR = (-0.17 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;

    // Module 2
    sm_lv_M2FL = (-0.34 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M2FR = (0.17 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M2RL = (0.17 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M2RR = (-0.34 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_pwm_handler(2);
    MotorDirection();

  case 3:
    // Module 3
    sm_lv_M3FL = (-0.17 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M3FR = ((sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M3RL = (-(sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M3RR = (-0.17 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;

    // Module 4
    sm_lv_M4FL = (-0.34 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4FR = (0.17 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4RL = (0.17 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4RR = (-0.34 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_pwm_handler(2);
    MotorDirection();
  case 4:
    // Module 4
    sm_lv_M4FL = (-(sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4FR = (0.17 * (-w) + (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4RL = (0.17 * (-w) - (sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_lv_M4RR = ((sm_wheel_x + sm_wheel_y) * (-w)) * 2;
    sm_pwm_handler(2);
    MotorDirection();
  }
}

void Smorphi::CenterPivotLeft(const int angular_velocity)
{
  
  double ang_speed = mapPosAng(angular_velocity);
  sm_velocity_handler(0, 0, ang_speed);
  int flag = 2;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::CenterPivotRight(const int angular_velocity)
{
  double ang_speed = mapNegAng(angular_velocity);
  sm_velocity_handler(0, 0, ang_speed);
  int flag = 2;
  sm_pwm_handler(flag);
  MotorDirection();
}

void Smorphi::stopSmorphi()
{ 
  M11->run(RELEASE);
  M12->run(RELEASE);
  M13->run(RELEASE);
  M14->run(RELEASE);

  M21->run(RELEASE);
  M22->run(RELEASE);
  M23->run(RELEASE);
  M24->run(RELEASE);

  M31->run(RELEASE);
  M32->run(RELEASE);
  M33->run(RELEASE);
  M34->run(RELEASE);

  M41->run(RELEASE);
  M42->run(RELEASE);
  M43->run(RELEASE);
  M44->run(RELEASE);
}

//clear the velocity variables for each module 
void Smorphi::sm_reset_M1()
{
  sm_lv_M1FL  =  0;
  sm_lv_M1FR  =  0;
  sm_lv_M1RL  =  0;
  sm_lv_M1RR  =  0;
}

void Smorphi::sm_reset_M2()
{
  sm_lv_M2FL  =  0;
  sm_lv_M2FR  =  0;
  sm_lv_M2RL  =  0;
  sm_lv_M2RR  =  0;
}

void Smorphi::sm_reset_M3()
{
  sm_lv_M3FL  =  0;
  sm_lv_M3FR  =  0;
  sm_lv_M3RL  =  0;
  sm_lv_M3RR  =  0;
}

void Smorphi::sm_reset_M4()
{
  sm_lv_M4FL  =  0;
  sm_lv_M4FR  =  0;
  sm_lv_M4RL  =  0;
  sm_lv_M4RR  =  0;
}

void Smorphi :: killSmorphi() {
  if (debug) Serial.println("Killing smorphi");
  sm_reset_M1();
  sm_reset_M2();
  sm_reset_M3();
  sm_reset_M4();
  stopSmorphi();
}

//interrupt testing
void Smorphi::interrupt_test()
{
  if(!digitalRead(INT_PIN_1))
  {
  Serial.print("Interrupt detected on mcp1 pin: ");
  Serial.println(mcp1.getLastInterruptPin());
  }
  if(!digitalRead(INT_PIN_2))
  { 
  Serial.print("Interrupt detected on mcp2 pin: ");
  Serial.println(mcp2.getLastInterruptPin());
  }
  if(!digitalRead(INT_PIN_3))
  {
  Serial.print("Interrupt detected on mcp3 pin: ");
  Serial.println(mcp3.getLastInterruptPin());
  }
  if(!digitalRead(INT_PIN_4))
  {
  Serial.print("Interrupt detected on mcp4 pin: ");
  Serial.println(mcp4.getLastInterruptPin());
  }
}

void Smorphi::staticKillSmorphi() {
  if (instance != nullptr) instance -> killSmorphi();
}

